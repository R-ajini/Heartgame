<?php

session_start();
include "db.php";

$user_id = $_SESSION['user_id'];

$sql = "SELECT username,email,recent_score FROM users WHERE id='$user_id'";
$result = mysqli_query($conn,$sql);

$row = mysqli_fetch_assoc($result);

$data = [
    "username"=>$row['username'],
    "email"=>$row['email'],
    "score"=>$row['recent_score']
];

echo json_encode($data);

?>