let level = localStorage.getItem("level") || "easy";

let cells;
let memorizeTime;
let recallTime;

if(level === "easy"){
    cells = 6;
    memorizeTime = 3;
    recallTime = 30;
}
else if(level === "medium"){
    cells = 9;
    memorizeTime = 2;
    recallTime = 20;
}
else{
    cells = 12;
    memorizeTime = 1.5;
    recallTime = 10;
}

let grid = document.getElementById("grid");
let score = 0;
let lives = 3;
let pattern = [];
let timer;

document.getElementById("lives").innerText = lives;
document.getElementById("score").innerText = score;

createGrid();

// Create the grid
function createGrid(){
    clearInterval(timer);
    grid.innerHTML="";

    for(let i=0;i<cells;i++){
        let cell = document.createElement("div");
        cell.className="cell";
        cell.dataset.index=i;
        cell.onclick = clickCell;
        grid.appendChild(cell);
    }

    generatePattern();
}

// Generate random pattern
function generatePattern(){
    pattern=[];
    let used = [];

    for(let i=0;i<Math.floor(cells/2);i++){
        let r;
        do{
            r = Math.floor(Math.random()*cells);
        }while(used.includes(r));
        used.push(r);
        pattern.push(r);
    }

    showPattern();
}

// Show pattern briefly
function showPattern(){
    grid.style.pointerEvents="none";
    pattern.forEach(i=> grid.children[i].classList.add("active"));

    setTimeout(()=>{
        pattern.forEach(i=> grid.children[i].classList.remove("active"));
        grid.style.pointerEvents="auto";
        startTimer();
    }, memorizeTime*1000);
}

// Handle cell click
function clickCell(){
    let index = Number(this.dataset.index);

    if(this.classList.contains("correct") || this.classList.contains("wrong")){
        return;
    }

    if(pattern.includes(index)){
        this.classList.add("correct");
        score++;
    } else {
        this.classList.add("wrong");
        lives--;
    }

    document.getElementById("score").innerText = score;
    document.getElementById("lives").innerText = lives;

    checkRound();
}

// Check if round finished
function checkRound(){
    let clickedCorrect = document.querySelectorAll(".correct").length;

   
    if(lives <= 0){
        clearInterval(timer);
        finishGame();
    }
}

// Timer function
function startTimer(){
    let time = recallTime;
    document.getElementById("time").innerText = time;

    timer = setInterval(()=>{
        time--;
        document.getElementById("time").innerText = time;

        if(time < 0){
            clearInterval(timer);
            finishGame();
        }

    },1000);
}

// Finish game and save results
function finishGame(){
    clearInterval(timer);

    let correct = score;
    let incorrect = Math.max(0, 3 - lives);
    let missed = Math.max(0, pattern.length - correct);

    let accuracy = 0;
    if(correct + incorrect > 0){
        accuracy = Math.round((correct/(correct+incorrect))*100);
    }

    let totalScore = score * 10;

    localStorage.setItem("totalScore", totalScore);
    localStorage.setItem("correct", correct);
    localStorage.setItem("incorrect", incorrect);
    localStorage.setItem("missed", missed);
    localStorage.setItem("accuracy", accuracy);

    window.location.href = "result.html";
}

// Submit button event
document.getElementById("submitBtn").addEventListener("click", function(){
    finishGame();
});