<?php

session_start();
include "db.php";

if(!isset($_SESSION['user_id'])){
exit;
}

$user_id = $_SESSION['user_id'];
$score = $_POST['score'];

$sql = "UPDATE users
SET
recent_score = '$score',
games_played = games_played + 1,
total_score = total_score + '$score',
best_score = GREATEST(best_score,'$score')
WHERE id='$user_id'";

mysqli_query($conn,$sql);

echo "success";

?>