<?php
session_start();
include "db.php";

if(!isset($_SESSION['user_id'])){
echo json_encode(["error"=>"not logged in"]);
exit;
}

$user_id = $_SESSION['user_id'];

$sql = "SELECT username,games_played,total_score,best_score,created_at FROM users WHERE id='$user_id'";
$result = mysqli_query($conn,$sql);

$row = mysqli_fetch_assoc($result);

echo json_encode($row);

?>