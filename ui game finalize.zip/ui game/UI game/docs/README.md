# UI Game Project

## Description
This is a web-based mini-game collection featuring a Memory Reaction mode, a Puzzle Matching mode, and a Math Speedrun mode. 

## Features
- User Authentication (Login / Signup) via PHP & MySQL.
- Session Management with PHP Sessions & Cookies.
- Three unique game modes.
- Integration with the Heart Game API for dynamic puzzles.

## Setup
1. Place the project folder in your local web server document root (e.g., `htdocs` for XAMPP).
2. Import the database schema required for the `users` table via `backend/setup_db.php`.
3. Open `index.html` in your web browser.

## Technologies Used
- HTML, CSS, JavaScript for frontend.
- PHP and MySQL for backend authentication and score saving.
- Heart Game API.
