# Software Design Document

## Overall Architecture
The application follows a client-server architecture. The frontend consists of HTML, CSS, and Vanilla JavaScript. The backend consists of PHP scripts to handle authentication and database interactions via MySQL.

## Design Principles

### Single Responsibility Principle
Each module and file is dedicated to a specific function in the application:
- `game.js` -> Handles the main logic for the memory game mode.
- `puzzle.js` -> Handles the logic for the puzzle matching game mode.
- `heartgame.js` -> Dedicated logic for the math speedrun game.
- `auth-guard.js` -> Purely responsible for verifying user authentication.
- `style.css` -> Global UI design.
- Backend PHP scripts (`login.php`, `signup.php`, `save_score.php`) handle their respective API endpoints natively without mixing responsibilities.

### Low Coupling & High Cohesion
- **High Cohesion**: Elements within the same module are tightly related. For example, all memory game state variables, timer functions, and grid interactions exist solely within `game.js`.
- **Low Coupling**: The frontend and backend communicate strictly via HTTP Requests (using Javascript's `fetch()` API). The Javascript game files do not care how the database works or how scores are stored; they simply call `save_score.php`. This makes the frontend and backend loosely coupled and independently modifiable.

## External APIs Integration
We integrate the **Heart Game API** (https://marcconrad.com/uob/heart/) to provide challenging visual math puzzles within the mini-games. This logic is decoupled and simply loaded via fetch calls inside the specific game modules.
