# Testing Report

## General Testing Criteria
- **Authentication**: Ensure users can sign up and log in.
- **Cookies & Sessions**: Verify sessions maintain state and explicitly set cookies keep track of the logged-in user.
- **Game Modes**: Each game mode initializes correctly, timer functions, and score logic counts as intended.
- **Error Handling**: API errors and database connection failures must be caught gracefully without blowing up the client console unhandled.

## Recent Fixes Verification
1. **File Conflicts**: Duplicate and typo HTML files (`memmorymode.html`, `memorymode.html`, `profie.html`, `puzzel.html`) removed. `memorymode.html` was successfully merged into `memory.html` without losing game initialization. Tested navigation from `gameselect.html` successfully.
2. **Cookies**: User authentication logic in `login.php` and `signup.php` was verified to trigger `setcookie()`. Tested cookies in the browser Developer Tools under Application -> Storage -> Cookies.
3. **API Logging/Error Handling**: Checked codebase to ensure `catch(error => console.log('API error'))` has been applied down the promise chain in `fetch` operations handling game state outputs.
4. **Code References**: Documented inline comments pointing to the `Heart Game API` throughout the application logic.

All components function as expected, maintaining high cohesion and low coupling.
