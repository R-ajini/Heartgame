// Simple front-end auth check using the profile endpoint.
// If the user is not logged in, they will be redirected to login.html
// Usage: include this script on pages that require authentication.

fetch("backend/profile.php")
  .then((res) => {
    if (!res.ok) {
      throw new Error("not ok");
    }
    return res.json();
  })
  .then((data) => {
    if (data && data.error === "not logged in") {
      window.location.href = "login.html";
    }
    // else: user is logged in, continue
  })
  .catch(() => {
    // On any error, be safe and send user to login
    window.location.href = "login.html";
  });

