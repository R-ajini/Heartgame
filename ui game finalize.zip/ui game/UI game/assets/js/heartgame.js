// Dedicated Heart Math Speedrun Game Logic

const heartUserScoreEl = document.getElementById("heartScore");
const heartTimeEl = document.getElementById("heartTime");
const heartGameplayImg = document.getElementById("heartGameplayImg");
const heartInput = document.getElementById("heartInput");
const submitAnswerBtn = document.getElementById("submitAnswerBtn");
const feedbackMessage = document.getElementById("feedbackMessage");

// Game State
let heartTimerId = null;
let currentHeartTimeLeft = 60; // seconds
let currentHeartSolution = null;
let heartTotalCorrect = 0;
let heartTotalIncorrect = 0;
let heartTotalScore = 0;
let isFetchingPuzzle = false;

const levelSelection = document.getElementById("levelSelection");
const gameArea = document.getElementById("gameArea");

let startingTimeLength = 60;

function startGameWithLevel(time) {
    if (levelSelection) levelSelection.style.display = "none";
    if (gameArea) gameArea.style.display = "block";
    startingTimeLength = time;
    initHeartGame();
}

// Event Listeners (set up once to avoid duplicates)
if (submitAnswerBtn) {
    submitAnswerBtn.onclick = checkHeartAnswer;
}

if (heartInput) {
    heartInput.addEventListener("input", function(e) {
        // Validation: no letters, digits only
        this.value = this.value.replace(/[^0-9]/g, '');
    });

    heartInput.addEventListener("keypress", function(event) {
        if (event.key === "Enter") {
            event.preventDefault();
            checkHeartAnswer();
        }
    });
}

/*
Heart Game API
https://marcconrad.com/uob/heart/
Used to generate puzzle images and solutions
*/

function initHeartGame() {
    // Reset State
    clearInterval(heartTimerId);
    currentHeartTimeLeft = startingTimeLength;
    currentHeartSolution = null;
    heartTotalCorrect = 0;
    heartTotalIncorrect = 0;
    heartTotalScore = 0;
    isFetchingPuzzle = false;

    if (heartUserScoreEl) heartUserScoreEl.innerText = "0";
    if (heartTimeEl) heartTimeEl.innerText = String(currentHeartTimeLeft);
    if (heartInput) {
        heartInput.value = "";
        heartInput.disabled = false;
        heartInput.focus();
    }
    
    if (feedbackMessage) {
        feedbackMessage.innerText = "Solve as many as you can before time runs out!";
        feedbackMessage.style.color = "inherit";
    }

    // Load first puzzle
    loadNextHeartPuzzle();

    // Start Timer
    startHeartTimer();
}

function startHeartTimer() {
    clearInterval(heartTimerId);
    heartTimerId = setInterval(() => {
        currentHeartTimeLeft--;
        if (heartTimeEl) heartTimeEl.innerText = String(Math.max(0, currentHeartTimeLeft));

        if (currentHeartTimeLeft <= 0) {
            clearInterval(heartTimerId);
            finishHeartGame();
        }
    }, 1000);
}

function loadNextHeartPuzzle() {
    if (!heartGameplayImg || isFetchingPuzzle) return;
    
    isFetchingPuzzle = true;
    heartInput.disabled = true; // Disable input while loading
    heartGameplayImg.style.opacity = "0.5";

    fetch("https://marcconrad.com/uob/heart/api.php")
        .then((res) => res.json())
        .then((data) => {
            if (data && data.question) {
                heartGameplayImg.src = data.question;
                if (typeof data.solution !== "undefined") {
                    currentHeartSolution = String(data.solution);
                }
            }
        })
        .catch((err) => {
            console.error("Failed to load Heart Game puzzle :", err);
            feedbackMessage.innerText = "Error loading puzzle. Retrying...";
            feedbackMessage.style.color = "orange";
            // Retry after brief delay
            setTimeout(() => {
                isFetchingPuzzle = false;
                loadNextHeartPuzzle();
            }, 2000);
            return;
        })
        .finally(() => {
            // Re-enable input once loaded (ensuring it's not finished)
            if (currentHeartTimeLeft > 0) {
                isFetchingPuzzle = false;
                heartGameplayImg.style.opacity = "1";
                heartInput.disabled = false;
                heartInput.value = "";
                heartInput.focus();
            }
        });
}

function checkHeartAnswer() {
    if (currentHeartTimeLeft <= 0 || isFetchingPuzzle) return;
    if (currentHeartSolution === null) return;

    const userAnswer = String(heartInput.value || "").trim();
    if (userAnswer === "") return;

    if (userAnswer === currentHeartSolution) {
        // Correct!
        heartTotalCorrect++;
        heartTotalScore += 50;
        showFeedback("Correct! +50", "green");
    } else {
        // Incorrect!
        heartTotalIncorrect++;
        heartTotalScore -= 10;
        showFeedback("Wrong! -10", "red");
    }

    if (heartTotalScore < 0) heartTotalScore = 0;
    if (heartUserScoreEl) heartUserScoreEl.innerText = String(heartTotalScore);

    // Clear input and load next puzzle immediately
    currentHeartSolution = null; 
    loadNextHeartPuzzle();
}

function showFeedback(msg, color) {
    if (feedbackMessage) {
        feedbackMessage.innerText = msg;
        feedbackMessage.style.color = color;
        
        // Reset feedback color after a moment
        setTimeout(() => {
            if(feedbackMessage.innerText === msg) {
                 feedbackMessage.style.color = "inherit";
                 feedbackMessage.innerText = "Keep going!";
            }
        }, 1500);
    }
}

// End the game
function finishHeartGame() {
    clearInterval(heartTimerId);
    if(heartInput) heartInput.disabled = true;
    if(submitAnswerBtn) submitAnswerBtn.disabled = true;

    // We don't have a fixed "total pairs", so we'll use attempts mapped to standard game variables
    const correct = heartTotalCorrect;
    const incorrect = heartTotalIncorrect;
    const missed = 0; // Not perfectly applicable to endless speedrun
    
    let accuracy = 0;
    if (correct + incorrect > 0) {
        accuracy = Math.round((correct / (correct + incorrect)) * 100);
    }

    // Store for shared result.html page
    localStorage.setItem("totalScore", String(heartTotalScore));
    localStorage.setItem("correct", String(correct));
    localStorage.setItem("incorrect", String(incorrect));
    localStorage.setItem("missed", String(missed));
    localStorage.setItem("accuracy", String(accuracy));

    // Optional UI update showing saving...
    if(feedbackMessage) {
         feedbackMessage.innerText = "Game Over! Saving score...";
         feedbackMessage.style.color = "blue";
    }

    // Send score to backend if logged in, then go to result page
    fetch("backend/save_score.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
        },
        body: "score=" + encodeURIComponent(heartTotalScore) + "&game_name=" + encodeURIComponent("Heart Game"),
    }).catch(error => console.log("API error")).finally(() => {
        window.location.href = "result.html";
    });
}
