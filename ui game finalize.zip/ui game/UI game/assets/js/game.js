// Memory Reaction Game Logic
// Uses localStorage "level" to configure difficulty

let cells;
let memorizeTime;
let recallTime;

let grid = document.getElementById("grid");
const heartImageEl = document.getElementById("heartImage");
const heartAnswerEl = document.getElementById("heartAnswer");
let heartSolution = null;
let score = 0;
let lives = 3;
let pattern = [];
let timer;

/*
Heart Game API
https://marcconrad.com/uob/heart/
Used to generate puzzle images and solutions
*/

function startMemoryGame(level) {
    if (level === "easy") {
        cells = 6;
        memorizeTime = 3;
        recallTime = 30;
    } else if (level === "medium") {
        cells = 9;
        memorizeTime = 2;
        recallTime = 20;
    } else {
        cells = 12;
        memorizeTime = 1.5;
        recallTime = 10;
    }

    score = 0;
    lives = 3;

    // Guard: if grid is not present, do nothing (prevents errors on other pages)
    if (grid) {
        const livesEl = document.getElementById("lives");
        const scoreEl = document.getElementById("score");

        if (livesEl) livesEl.innerText = lives;
        if (scoreEl) scoreEl.innerText = score;

        // Create the grid exactly as before
        createGrid();

        // Preload Heart Bonus Puzzle
        loadHeartPuzzle();

        // Wire submit button if it exists
        const submitBtn = document.getElementById("submitBtn");
        if (submitBtn) {
            submitBtn.addEventListener("click", function () {
                finishGame();
            });
        }
    }
}

// Create the grid
function createGrid() {
    clearInterval(timer);
    grid.innerHTML = "";

    for (let i = 0; i < cells; i++) {
        let cell = document.createElement("div");
        cell.className = "cell";
        cell.dataset.index = i;
        cell.onclick = clickCell;
        grid.appendChild(cell);
    }

    generatePattern();
}

// Generate random pattern
function generatePattern() {
    pattern = [];
    let used = [];

    for (let i = 0; i < Math.floor(cells / 2); i++) {
        let r;
        do {
            r = Math.floor(Math.random() * cells);
        } while (used.includes(r));
        used.push(r);
        pattern.push(r);
    }

    showPattern();
}

// Show pattern briefly
function showPattern() {
    grid.style.pointerEvents = "none";
    pattern.forEach((i) => grid.children[i].classList.add("active"));

    setTimeout(() => {
        pattern.forEach((i) => grid.children[i].classList.remove("active"));
        grid.style.pointerEvents = "auto";
        startTimer();
    }, memorizeTime * 1000);
}

// Handle cell click
function clickCell() {
    let index = Number(this.dataset.index);

    if (this.classList.contains("correct") || this.classList.contains("wrong")) {
        return;
    }

    if (pattern.includes(index)) {
        this.classList.add("correct");
        score++;
        // Fetch and display Heart image
        fetch("https://marcconrad.com/uob/heart/api.php")
            .then(res => res.json())
            .then(data => {
                if (data && data.question) {
                    this.style.backgroundImage = `url('${data.question}')`;
                    this.style.backgroundSize = 'cover';
                    this.style.backgroundPosition = 'center';
                    this.innerText = ''; // Clear existing text if any
                }
            })
            .catch(err => console.error("Heart API error:", err));
    } else {
        this.classList.add("wrong");
        lives--;
    }

    const livesEl = document.getElementById("lives");
    const scoreEl = document.getElementById("score");

    if (scoreEl) scoreEl.innerText = score;
    if (livesEl) livesEl.innerText = lives;

    checkRound();
}

// Check if round finished
function checkRound() {
    if (lives <= 0) {
        clearInterval(timer);
        startBonusRound();
        return;
    }

    // If all pattern cells have been correctly selected, stop input and wait for submit
    const correctClicked = Array.from(grid.children).filter((cell, idx) =>
        pattern.includes(idx) && cell.classList.contains("correct")
    ).length;

    if (correctClicked === pattern.length) {
        // All correct cells found: stop timer and disable further clicks.
        clearInterval(timer);
        grid.style.pointerEvents = "none";
        // Player will now press "Submit Answer" (finishGame now does bonus round transition)
        // Wait 1 second before auto-transitioning to bonus round so they see the result
        setTimeout(startBonusRound, 1000);
    }
}

// Timer function
function startTimer() {
    let time = recallTime;
    const timeEl = document.getElementById("time");
    if (timeEl) timeEl.innerText = time;

    timer = setInterval(() => {
        time--;
        if (timeEl) timeEl.innerText = time;

        if (time < 0) {
            clearInterval(timer);
            startBonusRound();
        }
    }, 1000);
}

// Load bonus puzzle image
function loadHeartPuzzle() {
    if (!heartImageEl) return;

    fetch("https://marcconrad.com/uob/heart/api.php")
        .then((res) => res.json())
        .then((data) => {
            if (data && data.question) {
                heartImageEl.src = data.question;
                heartImageEl.alt = "Heart Bonus Puzzle";
                if (typeof data.solution !== "undefined") {
                    heartSolution = String(data.solution);
                }
            }
        })
        .catch((err) => {
            console.error("Failed to load Heart Bonus puzzle:", err);
        });
}

// Transition to bonus round
function startBonusRound() {
    // Hide main game screen and show bonus screen
    document.getElementById("gameScreen").style.display = "none";
    document.getElementById("bonusScreen").style.display = "block";

    // Set up button listener for submitting bonus
    const submitBonusBtn = document.getElementById("submitBonusBtn");
    if (submitBonusBtn) {
        submitBonusBtn.onclick = finishGame;
    }
}

// Finish game and save results
function finishGame() {
    clearInterval(timer);

    let heartBonus = 0;
    if (heartAnswerEl && heartSolution !== null) {
        const userAnswer = String(heartAnswerEl.value || "").trim();
        if (userAnswer.length > 0) {
            if (userAnswer === heartSolution) {
                heartBonus = 50; // Bonus points for correct Heart Puzzle
            } else {
                heartBonus = -10; // Small penalty for wrong Heart Puzzle
            }
        }
    }

    let correct = score;
    let incorrect = Math.max(0, 3 - lives);
    let missed = Math.max(0, pattern.length - correct);

    let accuracy = 0;
    if (correct + incorrect > 0) {
        accuracy = Math.round((correct / (correct + incorrect)) * 100);
    }

    let totalScore = score * 10 + heartBonus;
    if (totalScore < 0) totalScore = 0;

    localStorage.setItem("totalScore", totalScore);
    localStorage.setItem("correct", correct);
    localStorage.setItem("incorrect", incorrect);
    localStorage.setItem("missed", missed);
    localStorage.setItem("accuracy", accuracy);

    fetch("backend/save_score.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
        },
        body: "score=" + encodeURIComponent(totalScore) + "&game_name=" + encodeURIComponent("Memory Game"),
    }).catch(error => console.log("API error")).finally(() => {
        // Regardless of success, go to result page
        window.location.href = "result.html";
    });
}

