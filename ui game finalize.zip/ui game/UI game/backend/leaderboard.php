<?php
session_start();
include "db.php";

header("Content-Type: application/json");

// Fetch the top 5 highest scorers from users table
$stmt = $conn->prepare("SELECT username, best_score FROM users ORDER BY best_score DESC LIMIT 5");
$stmt->execute();
$result = $stmt->get_result();

$leaderboard = [];
while ($row = $result->fetch_assoc()) {
    $leaderboard[] = $row;
}

$stmt->close();
$conn->close();

echo json_encode($leaderboard);
?>
