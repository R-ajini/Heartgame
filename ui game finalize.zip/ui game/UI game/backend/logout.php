<?php
session_start();
session_unset();
session_destroy();

// Simple logout endpoint – front-end can redirect after calling this
echo "logged_out";
