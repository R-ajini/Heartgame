<?php
include "c:/xampp/htdocs/ui game/UI game/backend/db.php";
$conn->query("ALTER TABLE score_history ADD COLUMN game_name VARCHAR(100) DEFAULT 'Unknown'");
echo "Done";
?>
